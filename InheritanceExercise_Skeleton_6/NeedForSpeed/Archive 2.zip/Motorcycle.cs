﻿using System;
namespace NeedForSpeed
{
    public class Motorcycle : Vehicle
    {
        public Motorcycle(double fuel, int horsePower) : base(fuel, horsePower)
        {
        }
    }
}

