﻿using System;
namespace NeedForSpeed
{
    public class FamilyCar : Car
    {
        public FamilyCar(double fuel, int horsePower) : base(fuel, horsePower)
        {
        }
    }
}

