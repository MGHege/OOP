﻿namespace Zoo
{
    internal class Snake
    {
    }
}