﻿namespace Zoo
{
    internal class Mammal
    {
    }
}