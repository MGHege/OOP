﻿namespace Zoo
{
    internal class Gorilla
    {
    }
}