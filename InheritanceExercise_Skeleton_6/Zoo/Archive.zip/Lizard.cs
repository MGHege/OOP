﻿namespace Zoo
{
    internal class Lizard
    {
    }
}