﻿namespace Zoo
{
    internal class Bear
    {
    }
}