﻿namespace Zoo
{
    internal class Animal
    {
    }
}