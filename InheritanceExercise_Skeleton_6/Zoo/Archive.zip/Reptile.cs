﻿namespace Zoo
{
    internal class Reptile
    {
    }
}